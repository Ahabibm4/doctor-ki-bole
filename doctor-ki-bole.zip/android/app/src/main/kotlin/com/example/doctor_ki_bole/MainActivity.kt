package com.example.doctor_ki_bole

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
